import streamlit as st
import pandas as pd
import joblib

# Load model
model = joblib.load("src/crop_yield_model.pkl")

# Load dataset
df = pd.read_csv("data/cleaned_crop_data.csv")

# Page title
st.set_page_config(
    page_title="AgriIntelligence",
    page_icon="🌾",
    layout="centered"
)

# Title
st.title("🌾 AgriIntelligence")
st.subheader("Crop Yield Prediction Platform")

st.write(
    "Enter agricultural and environmental information "
    "to predict crop yield."
)

# Country selection
country = st.selectbox(
    "Select Country",
    sorted(df["Country"].unique())
)

# Crop selection
crop = st.selectbox(
    "Select Crop",
    sorted(df["Crop"].unique())
)

# Year
year = st.number_input(
    "Year",
    min_value=int(df["Year"].min()),
    max_value=int(df["Year"].max()),
    value=int(df["Year"].max())
)

# Rainfall
rainfall = st.number_input(
    "Average Rainfall (mm/year)",
    min_value=0.0,
    value=float(df["Rainfall"].mean())
)

# Pesticides
pesticides = st.number_input(
    "Pesticides (tonnes)",
    min_value=0.0,
    value=float(df["Pesticides"].mean())
)

# Temperature
temperature = st.number_input(
    "Average Temperature",
    value=float(df["Temperature"].mean())
)

# Prediction button
if st.button("🌱 Predict Crop Yield"):

    input_data = pd.DataFrame({
        "Country": [country],
        "Crop": [crop],
        "Year": [year],
        "Rainfall": [rainfall],
        "Pesticides": [pesticides],
        "Temperature": [temperature]
    })

    prediction = model.predict(input_data)[0]

    st.success("Prediction completed!")

    st.metric(
        "🌾 Predicted Crop Yield",
        f"{prediction:,.2f} hg/ha"
    )