import streamlit as st
import pandas as pd
import joblib
import matplotlib.pyplot as plt
import seaborn as sns


# ============================================================
# PAGE SETTINGS
# ============================================================

st.set_page_config(
    page_title="AgriIntelligence",
    page_icon="🌾",
    layout="wide"
)


# ============================================================
# LOAD DATA AND MODEL
# ============================================================

df = pd.read_csv("data/cleaned_crop_data.csv")
market_df = pd.read_csv("data/cleaned_market_data.csv")

market_df["Arrival_Date"] = pd.to_datetime(
    market_df["Arrival_Date"],
    errors="coerce"
)

model = joblib.load("src/crop_yield_model.pkl")


# ============================================================
# TITLE
# ============================================================

st.title("🌾 AgriIntelligence")

st.subheader(
    "End-to-End Crop, Weather & Market Analytics Platform"
)

st.write(
    "Analyze crop yield, weather conditions, agricultural factors "
    "and market prices using data analytics and machine learning."
)


# ============================================================
# SIDEBAR
# ============================================================

st.sidebar.title("🌾 Navigation")

page = st.sidebar.radio(
    "Select Section",
    [
        "📊 Crop Analytics",
        "🌧️ Weather Analytics",
        "🧪 Agricultural Factors",
        "💰 Market Analytics",
        "🤖 Crop Yield Prediction"
    ]
)


# ============================================================
# 1. CROP ANALYTICS
# ============================================================

if page == "📊 Crop Analytics":

    st.header("📊 Crop Analytics")

    st.write(
        "Explore crop yield patterns across different countries "
        "and crop types."
    )

    # --------------------------------------------------------
    # Average Yield by Crop
    # --------------------------------------------------------

    st.subheader("Average Yield by Crop")

    crop_yield = (
        df.groupby("Crop")["Yield"]
        .mean()
        .sort_values(ascending=False)
    )

    fig, ax = plt.subplots(figsize=(10, 5))

    crop_yield.plot(
        kind="bar",
        ax=ax
    )

    ax.set_xlabel("Crop")
    ax.set_ylabel("Average Yield (hg/ha)")
    ax.set_title("Average Crop Yield")

    plt.xticks(rotation=45)
    plt.tight_layout()

    st.pyplot(fig)

    # --------------------------------------------------------
    # Top 10 Countries
    # --------------------------------------------------------

    st.subheader("Top 10 Countries by Average Yield")

    country_yield = (
        df.groupby("Country")["Yield"]
        .mean()
        .sort_values(ascending=False)
        .head(10)
    )

    fig, ax = plt.subplots(figsize=(10, 5))

    country_yield.plot(
        kind="bar",
        ax=ax
    )

    ax.set_xlabel("Country")
    ax.set_ylabel("Average Yield (hg/ha)")
    ax.set_title("Top 10 Countries by Average Yield")

    plt.xticks(rotation=45)
    plt.tight_layout()

    st.pyplot(fig)


# ============================================================
# 2. WEATHER ANALYTICS
# ============================================================

elif page == "🌧️ Weather Analytics":

    st.header("🌧️ Weather Analytics")

    st.write(
        "Compare rainfall and temperature ranges with average "
        "crop yield."
    )

    # --------------------------------------------------------
    # Rainfall Range vs Crop Yield
    # --------------------------------------------------------

    st.subheader("Rainfall Range vs Crop Yield")

    rainfall_bins = [
        0,
        500,
        1000,
        1500,
        2000,
        2500,
        3000,
        float("inf")
    ]

    rainfall_labels = [
        "0–500",
        "501–1000",
        "1001–1500",
        "1501–2000",
        "2001–2500",
        "2501–3000",
        ">3000"
    ]

    rainfall_range = pd.cut(
        df["Rainfall"],
        bins=rainfall_bins,
        labels=rainfall_labels,
        include_lowest=True
    )

    rainfall_yield = (
        df.assign(
            Rainfall_Range=rainfall_range
        )
        .groupby(
            "Rainfall_Range",
            observed=True
        )["Yield"]
        .mean()
        .reset_index()
    )

    fig, ax = plt.subplots(figsize=(10, 5))

    sns.barplot(
        data=rainfall_yield,
        x="Rainfall_Range",
        y="Yield",
        ax=ax
    )

    ax.set_title(
        "Average Crop Yield by Rainfall Range"
    )

    ax.set_xlabel(
        "Average Rainfall Range (mm/year)"
    )

    ax.set_ylabel(
        "Average Crop Yield (hg/ha)"
    )

    plt.xticks(rotation=0)
    plt.tight_layout()

    st.pyplot(fig)

    st.info(
        "Each bar represents the average crop yield for records "
        "falling within that rainfall range."
    )

    # --------------------------------------------------------
    # Temperature Range vs Crop Yield
    # --------------------------------------------------------

    st.subheader("Temperature Range vs Crop Yield")

    temperature_bins = [
        0,
        10,
        15,
        20,
        25,
        30,
        35
    ]

    temperature_labels = [
        "0–10",
        "11–15",
        "16–20",
        "21–25",
        "26–30",
        "30+"
    ]

    temperature_range = pd.cut(
        df["Temperature"],
        bins=temperature_bins,
        labels=temperature_labels,
        include_lowest=True
    )

    temperature_yield = (
        df.assign(
            Temperature_Range=temperature_range
        )
        .groupby(
            "Temperature_Range",
            observed=True
        )["Yield"]
        .mean()
        .reset_index()
    )

    fig, ax = plt.subplots(figsize=(10, 5))

    sns.barplot(
        data=temperature_yield,
        x="Temperature_Range",
        y="Yield",
        ax=ax
    )

    ax.set_title(
        "Average Crop Yield by Temperature Range"
    )

    ax.set_xlabel(
        "Average Temperature Range (°C)"
    )

    ax.set_ylabel(
        "Average Crop Yield (hg/ha)"
    )

    plt.xticks(rotation=0)
    plt.tight_layout()

    st.pyplot(fig)

    st.info(
        "Each bar represents the average crop yield for records "
        "falling within that temperature range."
    )


# ============================================================
# 3. AGRICULTURAL FACTORS
# ============================================================

elif page == "🧪 Agricultural Factors":

    st.header("Agricultural Factors")

    st.write(
        "Analyze pesticide usage and the relationship between "
        "agricultural factors and crop yield."
    )

    # --------------------------------------------------------
    # Pesticide Range vs Crop Yield
    # --------------------------------------------------------

    st.subheader(
        "Pesticide Usage Range vs Crop Yield"
    )

    pesticide_bins = [
        0,
        50000,
        100000,
        150000,
        200000,
        250000,
        300000,
        float("inf")
    ]

    pesticide_labels = [
        "0–50K",
        "51–100K",
        "101–150K",
        "151–200K",
        "201–250K",
        "251–300K",
        ">300K"
    ]

    pesticide_range = pd.cut(
        df["Pesticides"],
        bins=pesticide_bins,
        labels=pesticide_labels,
        include_lowest=True
    )

    pesticide_yield = (
        df.assign(
            Pesticide_Range=pesticide_range
        )
        .groupby(
            "Pesticide_Range",
            observed=True
        )["Yield"]
        .mean()
        .reset_index()
    )

    fig, ax = plt.subplots(figsize=(10, 5))

    sns.barplot(
        data=pesticide_yield,
        x="Pesticide_Range",
        y="Yield",
        ax=ax
    )

    ax.set_title(
        "Average Crop Yield by Pesticide Usage Range"
    )

    ax.set_xlabel(
        "Pesticide Usage Range (tonnes)"
    )

    ax.set_ylabel(
        "Average Crop Yield (hg/ha)"
    )

    plt.xticks(rotation=0)
    plt.tight_layout()

    st.pyplot(fig)

    st.info(
        "Each bar represents the average crop yield for records "
        "within that pesticide usage range."
    )

    # ========================================================
    # CORRELATION ANALYSIS
    # ========================================================

    st.subheader(
        "Correlation Between Agricultural Factors and Crop Yield"
    )

    st.write(
        "This heatmap shows the relationship between crop yield, "
        "rainfall, pesticide usage and temperature."
    )

    # --------------------------------------------------------
    # Select ONLY meaningful agricultural variables
    #
    # Year is intentionally excluded.
    # --------------------------------------------------------

    correlation_data = df[
        [
            "Yield",
            "Rainfall",
            "Pesticides",
            "Temperature"
        ]
    ].copy()

    # Calculate correlation
    correlation_matrix = correlation_data.corr()

    # Rename Yield for display
    correlation_matrix = correlation_matrix.rename(
        index={
            "Yield": "Crop Yield",
            "Rainfall": "Rainfall",
            "Pesticides": "Pesticides",
            "Temperature": "Temperature"
        },
        columns={
            "Yield": "Crop Yield",
            "Rainfall": "Rainfall",
            "Pesticides": "Pesticides",
            "Temperature": "Temperature"
        }
    )

    # --------------------------------------------------------
    # HEATMAP
    # --------------------------------------------------------

    fig, ax = plt.subplots(
        figsize=(10, 7)
    )

    sns.heatmap(
        correlation_matrix,
        annot=True,
        fmt=".2f",
        cmap="magma",
        vmin=-1,
        vmax=1,
        linewidths=2,
        linecolor="white",
        square=True,
        cbar=True,
        annot_kws={
            "size": 14
        },
        ax=ax
    )

    ax.set_title(
        "Correlation Between Agricultural Factors and Crop Yield",
        fontsize=17,
        pad=15
    )

    ax.set_xlabel(
        "Agricultural Variables",
        fontsize=13
    )

    ax.set_ylabel(
        "Agricultural Variables",
        fontsize=13
    )

    plt.xticks(
        rotation=0,
        fontsize=11
    )

    plt.yticks(
        rotation=0,
        fontsize=11
    )

    plt.tight_layout()

    st.pyplot(fig)

    # --------------------------------------------------------
    # EASY INTERPRETATION
    # --------------------------------------------------------

    st.markdown(
        "### Relationship with Crop Yield"
    )

    yield_correlation = (
        correlation_data
        .corr()["Yield"]
        .drop("Yield")
        .sort_values(
            ascending=False
        )
    )

    for factor, value in yield_correlation.items():

        # Determine strength
        if abs(value) < 0.10:
            strength = "very weak"

        elif abs(value) < 0.30:
            strength = "weak"

        elif abs(value) < 0.50:
            strength = "moderate"

        else:
            strength = "strong"

        # Determine direction
        if value > 0:
            direction = "positive"

        elif value < 0:
            direction = "negative"

        else:
            direction = "no"

        st.write(
            f"**{factor} → Crop Yield:** "
            f"{value:.2f} "
            f"({strength} {direction} correlation)"
        )

    st.caption(
        "Correlation ranges from -1 to +1. Values close to +1 "
        "indicate a positive relationship, values close to -1 "
        "indicate a negative relationship, and values close to 0 "
        "indicate a weak linear relationship. Correlation does "
        "not by itself prove causation."
    )


# ============================================================
# 4. MARKET ANALYTICS
# ============================================================

elif page == "💰 Market Analytics":

    st.header(
        "Agricultural Market Analytics"
    )

    st.write(
        "Analyze agricultural commodity prices across different "
        "markets and dates."
    )

    commodities = sorted(
        market_df["Commodity"]
        .dropna()
        .unique()
    )

    if len(commodities) == 0:

        st.warning(
            "No commodity data is available."
        )

    else:

        selected_commodity = st.selectbox(
            "Select Commodity",
            commodities
        )

        selected_data = market_df[
            market_df["Commodity"]
            == selected_commodity
        ].copy()

        # ----------------------------------------------------
        # Price Statistics
        # ----------------------------------------------------

        avg_price = (
            selected_data[
                "Modal_Price"
            ].mean()
        )

        min_price = (
            selected_data[
                "Min_Price"
            ].min()
        )

        max_price = (
            selected_data[
                "Max_Price"
            ].max()
        )

        col1, col2, col3 = st.columns(3)

        with col1:

            st.metric(
                "Average Modal Price",
                f"₹{avg_price:,.2f}"
            )

        with col2:

            st.metric(
                "Minimum Price",
                f"₹{min_price:,.2f}"
            )

        with col3:

            st.metric(
                "Maximum Price",
                f"₹{max_price:,.2f}"
            )

        # ----------------------------------------------------
        # Price Trend
        # ----------------------------------------------------

        st.subheader(
            "Price Trend"
        )

        price_trend = (
            selected_data
            .groupby(
                "Arrival_Date"
            )["Modal_Price"]
            .mean()
            .sort_index()
        )

        st.line_chart(
            price_trend
        )

        # ----------------------------------------------------
        # Market Comparison
        # ----------------------------------------------------

        st.subheader(
            "Market-wise Price Comparison"
        )

        market_comparison = (
            selected_data
            .groupby(
                "Market"
            )["Modal_Price"]
            .mean()
            .sort_values(
                ascending=False
            )
            .head(10)
        )

        st.bar_chart(
            market_comparison
        )

        # ----------------------------------------------------
        # Market Data
        # ----------------------------------------------------

        st.subheader(
            "Market Data"
        )

        display_columns = [
            "State",
            "District",
            "Market",
            "Commodity",
            "Arrival_Date",
            "Min_Price",
            "Max_Price",
            "Modal_Price"
        ]

        available_columns = [
            col
            for col in display_columns
            if col in selected_data.columns
        ]

        st.dataframe(
            selected_data[
                available_columns
            ].sort_values(
                "Arrival_Date",
                ascending=False
            ),
            use_container_width=True
        )


# ============================================================
# 5. CROP YIELD PREDICTION
# ============================================================

elif page == "🤖 Crop Yield Prediction":

    st.header(
        "Crop Yield Prediction"
    )

    st.write(
        "Enter agricultural and environmental information "
        "to predict crop yield using the trained machine "
        "learning model."
    )

    # --------------------------------------------------------
    # Country
    # --------------------------------------------------------

    country = st.selectbox(
        "Select Country",
        sorted(
            df["Country"]
            .dropna()
            .unique()
        )
    )

    # --------------------------------------------------------
    # Crop
    # --------------------------------------------------------

    crop = st.selectbox(
        "Select Crop",
        sorted(
            df["Crop"]
            .dropna()
            .unique()
        )
    )

    # --------------------------------------------------------
    # Year
    # --------------------------------------------------------

    year = st.number_input(
        "Year",
        min_value=int(
            df["Year"].min()
        ),
        max_value=int(
            df["Year"].max()
        ),
        value=int(
            df["Year"].max()
        )
    )

    # --------------------------------------------------------
    # Rainfall
    # --------------------------------------------------------

    rainfall = st.number_input(
        "Average Rainfall (mm/year)",
        min_value=0.0,
        value=float(
            df["Rainfall"].mean()
        )
    )

    # --------------------------------------------------------
    # Pesticides
    # --------------------------------------------------------

    pesticides = st.number_input(
        "Pesticides (tonnes)",
        min_value=0.0,
        value=float(
            df["Pesticides"].mean()
        )
    )

    # --------------------------------------------------------
    # Temperature
    # --------------------------------------------------------

    temperature = st.number_input(
        "Average Temperature (°C)",
        min_value=0.0,
        value=float(
            df["Temperature"].mean()
        )
    )

    # --------------------------------------------------------
    # Prediction
    # --------------------------------------------------------

    if st.button(
        "Predict Crop Yield"
    ):

        input_data = pd.DataFrame(
            {
                "Country": [country],
                "Crop": [crop],
                "Year": [year],
                "Rainfall": [rainfall],
                "Pesticides": [pesticides],
                "Temperature": [temperature]
            }
        )

        try:

            prediction = model.predict(
                input_data
            )[0]

            st.success(
                "Prediction completed!"
            )

            st.metric(
                "Predicted Crop Yield",
                f"{prediction:,.2f} hg/ha"
            )

            st.info(
                "The prediction is generated using "
                "the trained machine learning model."
            )

        except Exception as e:

            st.error(
                "Prediction could not be generated. "
                "Please check that the model was trained "
                "using the same input columns."
            )

            st.code(
                str(e)
            )