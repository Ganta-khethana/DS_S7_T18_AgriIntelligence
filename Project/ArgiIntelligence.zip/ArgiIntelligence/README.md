# AgriIntelligence

## Crop Yield Prediction Platform

AgriIntelligence is a machine learning based crop yield prediction platform.

## Objectives

- Predict crop yield using agricultural data
- Analyze environmental factors
- Study the effect of rainfall, temperature and pesticide usage
- Provide an easy-to-use prediction interface

## Technologies

- Python
- Pandas
- NumPy
- Matplotlib
- Seaborn
- Scikit-learn
- Joblib
- Streamlit

## Machine Learning

Random Forest Regression is used for crop yield prediction.

## Input Features

- Country
- Crop
- Year
- Average rainfall
- Pesticide usage
- Average temperature

## Evaluation Metrics

- MAE
- MSE
- RMSE
- R² Score

## Model Result

R² Score: 0.9876

The model achieved an R² score of approximately 98.76% on the test dataset.

## Application

The Streamlit application allows users to enter agricultural and environmental information and receive a predicted crop yield.

## How to Run

```bash
python -m streamlit run app.py

Save with **Ctrl + S**.

---

# STEP 10 — Final project structure

Your final project should look like this:

```text
ArgiIntelligence
│
├── data
│   ├── crop_data.csv
│   └── cleaned_crop_data.csv
│
├── notebooks
│   └── ArgiIntelligence.ipynb
│
├── src
│   ├── model.py
│   └── crop_yield_model.pkl
│
├── results
│   ├── feature_importance.png
│   ├── feature_importance_clean.png
│   ├── actual_vs_predicted.png
│   └── model_metrics.txt
│
├── app.py
├── app_backup.py
├── README.md
└── requirements.txt